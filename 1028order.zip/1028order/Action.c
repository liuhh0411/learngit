Action()
{

	web_url("javamall", 
		"URL=http://{IP}:8080/javamall", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/javamall/themes/default/images/dhctbj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/400phone.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/dhctzc.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/dhnn.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/dhctyc.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/ss.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/background-24.png", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/gwctbbj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/sysplbbj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/syhibj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/sygd.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/bzbj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/sylibj.jpg", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/ys.png", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		"Url=/javamall/themes/default/images/zctccdxb.gif", "Referer=http://{IP}:8080/javamall/", ENDITEM, 
		LAST);

	web_url("cart!getCartData.do", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691531797", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_2", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=themes/default/images/dhxtbj.jpg", ENDITEM, 
		LAST);

	web_url("cart_bar.html", 
		"URL=http://{IP}:8080/javamall/cart/cart_bar.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	web_url("cart_bar.html_2", 
		"URL=http://{IP}:8080/javamall/cart/cart_bar.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	/*��¼*/


	web_url("login.html", 
		"URL=http://{IP}:8080/javamall/login.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=themes/default/images/why.jpg", ENDITEM, 
		"Url=themes/default/images/dlbt.jpg", ENDITEM, 
		"Url=themes/default/images/dlbj.jpg", ENDITEM, 
		"Url=themes/default/images/jshop_button.jpg", ENDITEM, 
		"Url=themes/default/images/validate.gif", ENDITEM, 
		LAST);

	web_url("cart!getCartData.do_2", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691581599", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/login.html", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_3", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/login.html", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);


	web_submit_data("member!login.do", 
		"Action=http://{IP}:8080/javamall/api/shop/member!login.do?ajax=yes", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/login.html", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=action", "Value=login", ENDITEM, 
		"Name=forward", "Value=", ENDITEM, 
		"Name=username", "Value=piaobei", ENDITEM, 
		"Name=password", "Value=123123", ENDITEM, 
		"Name=validcode", "Value=1", ENDITEM, 
		LAST);

	web_url("member.html", 
		"URL=http://{IP}:8080/javamall/member/member.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../themes/default/images/hyzh1bj.jpg", ENDITEM, 
		"Url=../themes/default/images/hyzx.jpg", ENDITEM, 
		"Url=../themes/default/images/hyzs.jpg", ENDITEM, 
		"Url=../themes/default/images/hyycs.jpg", ENDITEM, 
		"Url=../themes/default/images/hybs.jpg", ENDITEM, 
		"Url=../themes/default/images/hysys.jpg", ENDITEM, 
		"Url=../themes/default/images/hysyx.jpg", ENDITEM, 
		"Url=../themes/default/images/yxsc.jpg", ENDITEM, 
		"Url=../themes/default/images/hyzc.jpg", ENDITEM, 
		"Url=../themes/default/images/tdlibj.jpg", ENDITEM, 
		"Url=../themes/default/images/hybx.jpg", ENDITEM, 
		"Url=../themes/default/images/hylyt.jpg", ENDITEM, 
		"Url=../themes/default/images/hyycx.jpg", ENDITEM, 
		"Url=../themes/default/images/dhxtyc.jpg", ENDITEM, 
		LAST);

	web_url("cart!getCartData.do_3", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691592772", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/member/member.html", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cart_bar.html_3", 
		"URL=http://{IP}:8080/javamall/cart/cart_bar.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/member/member.html", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	/*�����Ʒ*/


	web_url("goods-131.html", 
		"URL=http://{IP}:8080/javamall/goods-131.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/member/member.html", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=themes/default/images/wjxpl.jpg", ENDITEM, 
		"Url=themes/default/images/spxq.jpg", ENDITEM, 
		"Url=http://static.v4.javamall.com.cn/attachment/goods/201202231910375481.jpg", ENDITEM, 
		"Url=themes/default/images/hint.gif", ENDITEM, 
		LAST);

	web_url("cart!getCartData.do_4", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691621139", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/goods-131.html", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_4", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/goods-131.html", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("�µ�");


	web_submit_data("cart!addGoods.do", 
		"Action=http://{IP}:8080/javamall/api/shop/cart!addGoods.do?ajax=yes", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/goods-131.html", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=num", "Value=1", ENDITEM, 
		"Name=goodsid", "Value={p_goods_id}", ENDITEM, 
		"Name=action", "Value=addGoods", ENDITEM, 
		LAST);

	web_url("cart.html", 
		"URL=http://{IP}:8080/javamall/cart.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=themes/default/images/gwczyanz.jpg", ENDITEM, 
		"Url=themes/default/images/gwczyany.jpg", ENDITEM, 
		LAST);

	web_url("cart!getCartData.do_5", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691681476", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/cart.html", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_5", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/cart.html", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("checkout.html", 
		"URL=http://{IP}:8080/javamall/checkout.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cart!getCartData.do_6", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691708461", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_6", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(6);

	web_url("region!getChildren.do", 
		"URL=http://{IP}:8080/javamall/api/base/region!getChildren.do?ajax=yes&regionid=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("region!getChildren.do_2", 
		"URL=http://{IP}:8080/javamall/api/base/region!getChildren.do?ajax=yes&regionid=35", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);


	web_url("payment_list.html", 
		"URL=http://{IP}:8080/javamall/checkout/payment_list.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);


	web_url("dlytype_list.html", 
		"URL=http://{IP}:8080/javamall/checkout/dlytype_list.html?regionid=453", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("checkout_total.html", 
		"URL=http://{IP}:8080/javamall/checkout/checkout_total.html?regionId=453&typeId=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);


	web_submit_data("order!create.do", 
		"Action=http://{IP}:8080/javamall/api/shop/order!create.do?ajax=yes", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/checkout.html", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=province_id", "Value=1", ENDITEM, 
		"Name=province", "Value=����", ENDITEM, 
		"Name=city_id", "Value=35", ENDITEM, 
		"Name=city", "Value=������", ENDITEM, 
		"Name=region_id", "Value=453", ENDITEM, 
		"Name=region", "Value=������", ENDITEM, 
		"Name=shipAddr", "Value=������������ˮ�����������c1056", ENDITEM, 
		"Name=shipZip", "Value=100093", ENDITEM, 
		"Name=shipName", "Value=piaobei", ENDITEM, 
		"Name=shipMobile", "Value=13810000000", ENDITEM, 
		"Name=shipTel", "Value=12345678", ENDITEM, 
		"Name=shipDay", "Value=��������", ENDITEM, 
		"Name=saveAddress", "Value=yes", ENDITEM, 
		"Name=paymentId", "Value=1", ENDITEM, 
		"Name=typeId", "Value=1", ENDITEM, 
		"Name=receiptType", "Value=1", ENDITEM, 
		"Name=receiptTitle", "Value=", ENDITEM, 
		"Name=receiptContent", "Value=�칫��Ʒ", ENDITEM, 
		"Name=remark", "Value=", ENDITEM, 
		LAST);

	web_url("order_create_success.html", 
		"URL=http://{IP}:8080/javamall/order_create_success.html?orderid=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cart!getCartData.do_7", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691788901", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/order_create_success.html?orderid=1", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_url("cart!getCartData.do_8", 
		"URL=http://{IP}:8080/javamall/api/shop/cart!getCartData.do?ajax=yes&_=1540691788901", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/order_create_success.html?orderid=1", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_url("javamall_7", 
		"URL=http://{IP}:8080/javamall/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{IP}:8080/javamall/order_create_success.html?orderid=1", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=themes/default/images/dhxtyc.jpg", "Referer=http://{IP}:8080/javamall/order_create_success.html?orderid=1", ENDITEM, 
		LAST);

	lr_end_transaction("�µ�",LR_AUTO);

	return 0;
}
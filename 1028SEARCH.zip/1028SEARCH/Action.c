Action()
{
	
	lr_start_transaction("search");

	web_reg_save_param("find_search",
		"LB=[{",
		"RB=}]",
		"Ord=1",
		"Search=All",
		LAST);


	web_url("web_url",
		"URL=http://{IP}:8080/javamall/api/shop/goods!search.do?cartid={CART_ID}&brandid={BRAND_ID}&keyword={SN}",//0000567840
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		LAST);

	if(strlen(lr_eval_string("{find_search}")) > 0){
		
		lr_end_transaction("search", LR_PASS);
	}else{
		lr_end_transaction("search", LR_FAIL);
	}

	

	return 0;
}

Action()
{
char temp[1000];
char str[1000];

	web_custom_request("add_cart", "Method=POST",

		"URL=http://192.168.100.146:8080/javamall/api/shop/member!login.do",

		"Body=username=piaobei&password=123123",

		LAST );

	web_custom_request("add_cart", "Method=POST",

		"URL=http://192.168.100.146:8080/javamall/api/shop/cart!addGoods.do",

		"Body=goodsid=130&num=1",

		LAST );

	web_reg_save_param("Response",
		"LB=result\":",
		"RB=,\"",
		"Ord=1",
		"Search=All",
		LAST);

	lr_start_transaction("order");

	web_custom_request("Order", "Method=POST", 

		"URL=http://192.168.100.146:8080/javamall/api/shop/order!create.do", 
	
		"Body=addressId=2&paymentId=1&typeId=1", 
	
		LAST ); 

	lr_convert_string_encoding(lr_eval_string("{Response}"),LR_ENC_UTF8,LR_ENC_SYSTEM_LOCALE, "temp");

strcpy(str,lr_eval_string("{temp}"));

lr_save_string(str,"temp");


lr_output_message("����ʹ�ñ��� = ��%s��",lr_eval_string("{temp}")); 
    
	if (atoi(lr_eval_string("{temp}"))==1) {
		lr_end_transaction("order", LR_PASS);
	}else{
		lr_end_transaction("order", LR_FAIL);

	}




	return 0;
}
